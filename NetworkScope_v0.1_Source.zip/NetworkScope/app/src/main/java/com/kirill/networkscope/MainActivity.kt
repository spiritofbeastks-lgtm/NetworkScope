package com.kirill.networkscope
import android.net.*
import android.net.TrafficStats
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.net.Inet4Address

val BG=Color(0xFF071019);val PANEL=Color(0xFF0E1B25);val CYAN=Color(0xFF16C7FF);val GREEN=Color(0xFF25E38B);val YELLOW=Color(0xFFFFD43B)

data class NetSample(val rx:Long,val tx:Long,val rxBps:Double,val txBps:Double,val time:Long)
data class NetInfo(val transport:String="NONE",val validated:Boolean=false,val metered:Boolean=false,val iface:String="—",val ips:String="—",val dns:String="—",val downKbps:Int=0,val upKbps:Int=0)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme{App(this)}}}
}
fun networkInfo(a:ComponentActivity):NetInfo{
 val cm=a.getSystemService(ConnectivityManager::class.java);val n=cm.activeNetwork?:return NetInfo()
 val c=cm.getNetworkCapabilities(n);val l=cm.getLinkProperties(n)
 val tr=when{c?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)==true->"Wi‑Fi";c?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)==true->"Cellular";c?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)==true->"Ethernet";c?.hasTransport(NetworkCapabilities.TRANSPORT_VPN)==true->"VPN";else->"Other"}
 return NetInfo(tr,c?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)==true,c?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)!=true,l?.interfaceName?:"—",l?.linkAddresses?.joinToString{it.address.hostAddress?:""}?:"—",l?.dnsServers?.joinToString{it.hostAddress?:""}?:"—",c?.linkDownstreamBandwidthKbps?:0,c?.linkUpstreamBandwidthKbps?:0)
}
@Composable fun App(a:ComponentActivity){
 var page by remember{mutableStateOf("Overview")};var sample by remember{mutableStateOf(NetSample(0,0,0.0,0.0,0))};var info by remember{mutableStateOf(NetInfo())};val hist=remember{mutableStateListOf<NetSample>()}
 LaunchedEffect(Unit){var pr=TrafficStats.getTotalRxBytes();var pt=TrafficStats.getTotalTxBytes();var tm=System.nanoTime();while(true){delay(500);val r=TrafficStats.getTotalRxBytes();val t=TrafficStats.getTotalTxBytes();val now=System.nanoTime();val sec=(now-tm)/1e9;sample=NetSample(r,t,(r-pr)/sec,(t-pt)/sec,System.currentTimeMillis());pr=r;pt=t;tm=now;info=networkInfo(a);hist.add(sample);if(hist.size>120)hist.removeAt(0)}}
 Row(Modifier.fillMaxSize().background(BG)){Nav(page){page=it};Column(Modifier.weight(1f).padding(12.dp)){Header(sample,info);Spacer(Modifier.height(10.dp));when(page){"Overview"->Overview(sample,info,hist);"Network"->NetworkPage(info);"Traffic"->Traffic(sample,hist);"Packets"->Packets();"DNS"->Dns(info);"Deep Capture"->DeepCapture();else->Overview(sample,info,hist)}}}
}
@Composable fun Nav(s:String,on:(String)->Unit){val xs=listOf("Overview","Network","Traffic","Packets","DNS","Deep Capture");Column(Modifier.width(130.dp).fillMaxHeight().background(Color(0xFF08141D)).padding(top=18.dp)){Text("NETWORK",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=14.dp));Text("SCOPE",color=CYAN,fontSize=13.sp,modifier=Modifier.padding(horizontal=14.dp));Spacer(Modifier.height(18.dp));xs.forEach{x->Box(Modifier.fillMaxWidth().height(56.dp).background(if(x==s)Color(0xFF12344A)else Color.Transparent).clickable{on(x)},contentAlignment=Alignment.Center){Text(x,color=if(x==s)Color.White else Color.LightGray,fontSize=12.sp)}}}}
fun rate(x:Double)=when{ x>=125000000->"%.2f Gbps".format(x*8/1e9);x>=125000->"%.2f Mbps".format(x*8/1e6);x>=125->"%.1f Kbps".format(x*8/1e3);else->"%.0f bps".format(x*8)}
fun bytes(x:Long)=when{x>=1073741824->"%.2f GB".format(x/1073741824.0);x>=1048576->"%.1f MB".format(x/1048576.0);x>=1024->"%.1f KB".format(x/1024.0);else->"$x B"}
@Composable fun Header(s:NetSample,n:NetInfo){Row(Modifier.fillMaxWidth().height(86.dp).background(PANEL,RoundedCornerShape(12.dp)).padding(15.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("${n.transport} • ${if(n.validated)"Internet validated" else "Not validated"}",color=if(n.validated)GREEN else YELLOW,fontWeight=FontWeight.Bold);Text("Interface ${n.iface}",color=Color.Gray)};Big("↓",rate(s.rxBps),GREEN);Spacer(Modifier.width(28.dp));Big("↑",rate(s.txBps),CYAN)}}
@Composable fun Big(a:String,b:String,c:Color){Row(verticalAlignment=Alignment.CenterVertically){Text(a,color=c,fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.width(7.dp));Text(b,color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Bold)}}
@Composable fun Tile(a:String,b:String,c:String="",m:Modifier=Modifier){Card(m.padding(5.dp),colors=CardDefaults.cardColors(containerColor=PANEL)){Column(Modifier.fillMaxSize().padding(13.dp),verticalArrangement=Arrangement.SpaceBetween){Text(a,color=Color.LightGray,fontSize=12.sp);Text(b,color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold);if(c.isNotBlank())Text(c,color=Color.Gray,fontSize=11.sp)}}}
@Composable fun Overview(s:NetSample,n:NetInfo,h:List<NetSample>){Column{Row(Modifier.weight(1f)){Tile("Download now",rate(s.rxBps),"real TrafficStats delta",Modifier.weight(1f));Tile("Upload now",rate(s.txBps),"real TrafficStats delta",Modifier.weight(1f));Tile("Total RX",bytes(s.rx),"since device boot",Modifier.weight(1f));Tile("Total TX",bytes(s.tx),"since device boot",Modifier.weight(1f))};Row(Modifier.weight(1f)){Tile("Transport",n.transport,"active default network",Modifier.weight(1f));Tile("Estimated link ↓","${n.downKbps/1000.0} Mbps","NetworkCapabilities estimate",Modifier.weight(1f));Tile("Estimated link ↑","${n.upKbps/1000.0} Mbps","NetworkCapabilities estimate",Modifier.weight(1f));Tile("Metered",if(n.metered)"YES" else "NO","system capability",Modifier.weight(1f))};Card(Modifier.fillMaxWidth().height(115.dp).padding(5.dp),colors=CardDefaults.cardColors(containerColor=PANEL)){Column(Modifier.padding(12.dp)){Text("Live history • last ${h.size} samples",color=Color.White);Text("↓ "+h.takeLast(12).joinToString("  "){rate(it.rxBps)},color=GREEN,fontSize=11.sp);Text("↑ "+h.takeLast(12).joinToString("  "){rate(it.txBps)},color=CYAN,fontSize=11.sp)}}}}
@Composable fun NetworkPage(n:NetInfo){Column{Row(Modifier.weight(1f)){Tile("Interface",n.iface,m=Modifier.weight(1f));Tile("Transport",n.transport,m=Modifier.weight(1f));Tile("Internet",if(n.validated)"VALIDATED" else "NOT VALIDATED",m=Modifier.weight(1f))};Row(Modifier.weight(1f)){Tile("Local addresses",n.ips,m=Modifier.weight(1f));Tile("DNS",n.dns,m=Modifier.weight(1f))}}}
@Composable fun Traffic(s:NetSample,h:List<NetSample>){Column{Row(Modifier.weight(1f)){Tile("Current RX",rate(s.rxBps),m=Modifier.weight(1f));Tile("Current TX",rate(s.txBps),m=Modifier.weight(1f));Tile("Samples","${h.size}","500 ms interval",Modifier.weight(1f))};Row(Modifier.weight(1f)){Tile("Peak RX",rate(h.maxOfOrNull{it.rxBps}?:0.0),m=Modifier.weight(1f));Tile("Peak TX",rate(h.maxOfOrNull{it.txBps}?:0.0),m=Modifier.weight(1f));Tile("Source","Android TrafficStats","device-wide byte counters",Modifier.weight(1f))}}}
@Composable fun Packets(){Page("Packets","v0.1 does NOT invent packet counts. Android TrafficStats gives byte counters, not a raw packet feed. Packet/IP/port inspection will be implemented only through a real VpnService capture engine.")}
@Composable fun Dns(n:NetInfo){Page("DNS","Active network DNS servers:\n\n${n.dns}\n\nPer-query DNS logging requires Deep Capture or a local DNS/VPN path; v0.1 does not fabricate it.")}
@Composable fun DeepCapture(){Page("Deep Capture • not enabled yet","Planned: Android VpnService → TUN packet parser → IPv4/IPv6 → TCP/UDP/ICMP metadata → flows, ports, PPS and packet sizes.\n\nIt is deliberately disabled in v0.1: a VPN service that captures packets without correctly forwarding them would break internet access.")}
@Composable fun Page(t:String,s:String){Column(Modifier.fillMaxSize().background(PANEL,RoundedCornerShape(12.dp)).padding(22.dp)){Text(t,color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(18.dp));Text(s,color=Color.LightGray,fontSize=15.sp)}}
